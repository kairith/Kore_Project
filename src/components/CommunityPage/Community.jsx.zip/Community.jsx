import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../AuthContext";

const CommunityPage = () => {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState("");
  const [newComment, setNewComment] = useState({});
  const [identity, setIdentity] = useState("Anonymous");
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState(null);
  const [likedPosts, setLikedPosts] = useState(new Set());
  const [selectedPost, setSelectedPost] = useState(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  // Added missing state variables
  const [isEditing, setIsEditing] = useState(false);
  const [editProfile, setEditProfile] = useState({ phone: "", gender: "", profileImage: null });
  const [editError, setEditError] = useState(null);

  const { user } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLike = async (postId) => {
    console.log("Liking post:", postId);
    try {
      const response = await fetch(`http://localhost:8000/likes/`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: new URLSearchParams({ post_id: postId }),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          `HTTP error! status: ${response.status}, detail: ${errorData.detail}`
        );
      }
      const data = await response.json();
      console.log("Like response:", data);

      setLikedPosts((prev) => {
        const updatedLikedPosts = new Set(prev);
        if (updatedLikedPosts.has(postId)) {
          updatedLikedPosts.delete(postId);
        } else {
          updatedLikedPosts.add(postId);
        }
        return updatedLikedPosts;
      });
    } catch (error) {
      console.error("Error liking post:", error);
    }
  };

  // Moved handleEditProfile out of useEffect
  const handleEditProfile = async (e) => {
    e.preventDefault();
    setEditError(null);

    const formData = new FormData();
    if (editProfile.phone) formData.append("phone", editProfile.phone);
    if (editProfile.gender) formData.append("gender", editProfile.gender);
    if (editProfile.profileImage) formData.append("profileImage", editProfile.profileImage);

    const token = localStorage.getItem("token");
    try {
      const response = await axios.put("http://localhost:8000/profile", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      });

      setUserProfile(response.data.user); // Update profile with new data
      setIsEditing(false); // Exit edit mode
      setEditProfile({
        phone: response.data.user.phone || "",
        gender: response.data.user.gender || "",
        profileImage: null,
      });
    } catch (error) {
      console.error("❌ Edit Profile Error:", error);
      setEditError(error.response?.data?.message || "Failed to update profile");
    }
  };

  useEffect(() => {
    const fetchProfile = async () => {
      const token = sessionStorage.getItem("token");
      console.log("🔍 Token from sessionStorage:", token);
    
      if (!token || token === "undefined") {
        console.error("❌ No valid token found. Redirecting to login.");
        navigate("/");  // Consider "/login" for clarity
        return;
      }
    
      try {
        const response = await fetch("http://localhost:8000/profile/", {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${token}`,
            "Accept": "application/json",
          },
        });
    
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(`Failed to fetch profile: ${errorData.detail || response.statusText}`);
        }
    
        const profileData = await response.json();
        console.log("✅ Profile Data:", profileData);
    
        setUserProfile(profileData);
        setIdentity(`${profileData.firstName} ${profileData.lastName}`);
        setEditProfile({
          phone: profileData.phone || "",
          gender: profileData.gender || "",
          profileImage: null,
        });
      } catch (error) {
        console.error("❌ Profile Fetch Error:", error.message);
        alert(error.message);
        navigate("/");  // Redirect to login on error instead of /community
      }
    };
    

    const fetchPosts = async () => {
      try {
        const token = sessionStorage.getItem("token");  // Changed to sessionStorage
        const response = await axios.get("http://localhost:8000/posts/", {
          headers: { "Authorization": `Bearer ${token}` },
        });
        console.log("Fetched Posts:", response.data);  // Debug
        setPosts(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching posts:", error.response?.data || error.message);
        setLoading(false);
      }
    };

    fetchPosts();
    fetchProfile();
  }, [navigate]);

  const handleNewPost = async () => {
    if (!newPost.trim()) return;
  
    const formData = new FormData();
    formData.append("user_id", userProfile?._id); // Changed to _id for consistency
    formData.append("content", newPost);
    formData.append("identity", identity);
  
    if (images.length > 0) {
      images.forEach((img) => formData.append("images", img));
    }
  
    const token = sessionStorage.getItem("token");  // Changed to sessionStorage
    try {
      const response = await axios.post("http://localhost:8000/posts/", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      });
      setNewPost("");
      setIdentity("Anonymous");
      setImages([]);
      setPosts((prevPosts) => [response.data, ...prevPosts]);
    } catch (error) {
      console.error("Error creating post:", error);
    }
  };

  const handleNewComment = async (postId) => {
    const comment = newComment[postId];
    if (!comment) {
      console.error("Comment cannot be empty");
      return;
    }
  
    const token = sessionStorage.getItem("token");  // Changed to sessionStorage
    try {
      const formData = new FormData();
      formData.append("post_id", postId);
      formData.append("content", comment);
  
      const response = await fetch(`http://localhost:8000/comments/`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
  
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const data = await response.json();
      setPosts((prevPosts) =>
        prevPosts.map((post) =>
          post.id === postId
            ? { ...post, comments: [...(post.comments || []), data] }
            : post
        )
      );
      setNewComment((prev) => ({ ...prev, [postId]: "" }));
    } catch (error) {
      console.error("Error adding comment:", error);
    }
  };

  // Full-screen image viewer handlers (unchanged)
  const handlePostClick = (post) => {
    if (post.image_urls && post.image_urls.length > 0) {
      setSelectedPost(post);
      setCurrentImageIndex(0);
    }
  };

  const handleNextImage = () => {
    if (selectedPost && currentImageIndex < selectedPost.image_urls.length - 1) {
      setCurrentImageIndex(currentImageIndex + 1);
    }
  };

  const handlePrevImage = () => {
    if (selectedPost && currentImageIndex > 0) {
      setCurrentImageIndex(currentImageIndex - 1);
    }
  };

  const handleClose = () => {
    setSelectedPost(null);
  };

  const handleKeyDown = (event) => {
    if (!selectedPost) return;
    switch (event.key) {
      case "ArrowLeft":
        handlePrevImage();
        break;
      case "ArrowRight":
        handleNextImage();
        break;
      case "Escape":
        handleClose();
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    if (selectedPost) {
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [selectedPost, currentImageIndex]);

  // Render image grid (unchanged)
  const renderImageGrid = (media) => {
    const imageCount = media.length;

    if (imageCount === 1) {
      return (
        <div className="grid grid-cols-1">
          <img
            src={media[0]}
            alt="Post Media"
            className="object-cover w-full h-64 rounded-lg"
          />
        </div>
      );
    }

    if (imageCount === 2) {
      return (
        <div className="grid grid-cols-2 gap-1">
          {media.map((img, index) => (
            <img
              key={index}
              src={img}
              alt="Post Media"
              className="object-cover w-full h-48 rounded-lg"
            />
          ))}
        </div>
      );
    }

    if (imageCount === 3) {
      return (
        <div className="grid grid-cols-2 gap-1">
          <img
            src={media[0]}
            alt="Post Media"
            className="object-cover w-full h-64 rounded-lg row-span-2"
          />
          <img
            src={media[1]}
            alt="Post Media"
            className="object-cover w-full h-32 rounded-lg"
          />
          <img
            src={media[2]}
            alt="Post Media"
            className="object-cover w-full h-32 rounded-lg"
          />
        </div>
      );
    }

    if (imageCount >= 4) {
      return (
        <div className="grid grid-cols-2 gap-1">
          <img
            src={media[0]}
            alt="Post Media"
            className="object-cover w-full h-64 rounded-lg row-span-2"
          />
          <img
            src={media[1]}
            alt="Post Media"
            className="object-cover w-full h-32 rounded-lg"
          />
          <img
            src={media[2]}
            alt="Post Media"
            className="object-cover w-full h-32 rounded-lg"
          />
          {imageCount > 4 && (
            <div className="relative">
              <img
                src={media[3]}
                alt="Post Media"
                className="object-cover w-full h-32 rounded-lg"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center text-white rounded-lg">
                +{imageCount - 4}
              </div>
            </div>
          )}
        </div>
      );
    }

    return null;
  };

  return (
    <div className="flex p-6 bg-gray-100 rounded-lg shadow-md h-screen">
      {/* Posts Section */}
      <div className="w-2/3 pr-4 overflow-y-auto h-full">
        <h2 className="text-2xl font-semibold mb-6 text-center">Community Posts</h2>
        {loading ? (
          <p>Loading posts...</p>
        ) : (
          <div>
            <div className="">
              <textarea
                placeholder="ចែករំលែកនៅទីនេះ..."
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                className="font-regular w-full p-3 border border-gray-400 rounded-lg mb-4 focus:outline-none focus:ring-1 focus:ring-blue-200"
              />
              <div className="flex gap-6">
                <select
                  value={identity}
                  onChange={(e) => setIdentity(e.target.value)}
                  className="font-regular w-[20%] mb-4 h-10 border border-gray-400 rounded-lg p-2 focus:outline-none focus:ring-1 focus:ring-blue-200"
                >
                  <option value="Anonymous" className="font-regular">
                    មិនបង្ហាញអត្តសញ្ញាណ
                  </option>
                  <option value={`${userProfile?.firstName} ${userProfile?.lastName}`}>
                    {userProfile ? `${userProfile.firstName} ${userProfile.lastName}` : "បង្ហាញអត្តសញ្ញាណ"}
                  </option>
                </select>
                <label htmlFor="file-upload" className="block mb-4 cursor-pointer">
                  <span className="inline-block px-4 py-2 text-white h-10 bg-blue-500 rounded-lg hover:bg-blue-600">
                    Upload Images
                  </span>
                  <input
                    type="file"
                    multiple
                    onChange={(e) => setImages([...e.target.files])}
                    id="file-upload"
                    className="hidden"
                  />
                </label>
                <button
                  onClick={handleNewPost}
                  className="bg-blue-500 text-white h-10 py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-300"
                >
                  Post
                </button>
              </div>
            </div>

            {/* Posts List */}
            <div className="mt-4">
  {[...posts]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((post) => (
      <div
        key={post.id || post.post_id}
        className="bg-white rounded-lg shadow-md p-4 mb-4 cursor-pointer"
        onClick={() => handlePostClick(post)}
      >
        {/* Status Messages */}
        {post.status === "pending" && (
          <p className="text-yellow-500">Pending Approval...</p>
        )}
        {post.status === "approved" && (
          <p className="text-green-500">✅ Approved</p>
        )}

        <div className="flex items-center mb-2">
          <img
            src={
              post.identity === "Anonymous"
                ? "/default-avatar.png"
                : (post.author?.profileImage || "/default-avatar.png")
            }
            alt="User"
            className="w-10 h-10 rounded-full mr-3"
            onError={(e) => (e.target.src = "/default-avatar.png")}
          />
          <h3 className="font-semibold">
            {post.identity === "Anonymous" ? "Anonymous" : `${post.author?.firstName} ${post.author?.lastName}`}
          </h3>
        </div>
        <p className="text-gray-800 mb-2">{post.content}</p>
        {post.createdAt && (
          <p className="text-gray-500 text-sm mb-2">
            Posted on: {new Date(post.createdAt).toLocaleString()}
          </p>
        )}
        {post.image_urls && Array.isArray(post.image_urls) && (
          <div className="mt-2">
            {renderImageGrid(post.image_urls)}
          </div>
        )}
        <div className="flex justify-between mt-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleLike(post.id);
            }}
            className={`py-1 px-2 rounded-lg transition duration-300 ${
              likedPosts.has(post.id) ? "bg-red-500" : "bg-green-500"
            } text-white`}
          >
            {likedPosts.has(post.id) ? "Unlike" : "Like"} {post.likes}
          </button>
        </div>

        <div className="mt-4">
          <p>Comments as</p>
          <select
            value={identity}
            onChange={(e) => setIdentity(e.target.value)}
            className="mb-4 border rounded-lg p-2"
          >
            <option value="Anonymous">Anonymous</option>
            <option value={`${userProfile?.firstName} ${userProfile?.lastName}`}>
              {userProfile ? `${userProfile.firstName} ${userProfile.lastName}` : "YourUsername"}
            </option>
          </select>
          <textarea
            placeholder="Write a comment..."
            value={newComment[post.id] || ""}
            onChange={(e) =>
              setNewComment((prev) => ({
                ...prev,
                [post.id]: e.target.value,
              }))
            }
            className="w-full p-2 border rounded-lg mb-2"
          />
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleNewComment(post.id);
            }}
            className="bg-blue-500 text-white py-1 px-2 rounded-lg hover:bg-blue-600 transition duration-300"
          >
            Comment
          </button>
        </div>

        <div className="mt-2">
          {post.comments &&
            post.comments.map((comment) => (
              <div key={comment.id} className="bg-gray-200 p-2 rounded-lg mb-2">
                <span className="font-bold text-gray-600">
                  {comment.identity || userProfile?.firstName}:
                </span>
                <span>{comment.content}</span>
              </div>
            ))}
        </div>
      </div>
    ))}
</div>
          </div>
        )}
      </div>

      {/* User Account Section with Edit Profile */}
      <div className="w-1/3 pl-4 h-full overflow-y-auto">
        {userProfile && (
          <div className="bg-white rounded-lg shadow-md p-4">
            <h3 className="text-lg font-semibold mb-2">User Account</h3>
            <img
              src={userProfile.profileImage || "/default-avatar.png"}
              alt="Profile"
              className="rounded-full w-24 h-24 mb-2 object-cover"
              onError={(e) => (e.target.src = "/default-avatar.png")}
            />
            <p className="text-gray-700">{userProfile.firstName} {userProfile.lastName}</p>
            <p className="text-gray-500">{userProfile.email}</p>
            <p className="text-gray-500">Phone: {userProfile.phone || "Not set"}</p>
            <p className="text-gray-500">Gender: {userProfile.gender || "Not set"}</p>

            {isEditing ? (
              <form onSubmit={handleEditProfile} className="mt-4">
                <div className="mb-2">
                  <label className="block text-sm font-medium">Phone</label>
                  <input
                    type="tel"
                    value={editProfile.phone}
                    onChange={(e) => setEditProfile({ ...editProfile, phone: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                    placeholder="Enter phone number"
                  />
                </div>
                <div className="mb-2">
                  <label className="block text-sm font-medium">Gender</label>
                  <select
                    value={editProfile.gender}
                    onChange={(e) => setEditProfile({ ...editProfile, gender: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                  >
                    <option value="">Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div className="mb-2">
                  <label className="block text-sm font-medium">Profile Image</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setEditProfile({ ...editProfile, profileImage: e.target.files[0] })}
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
                {editError && <p className="text-red-500 text-sm mb-2">{editError}</p>}
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="bg-blue-500 text-white py-1 px-2 rounded-lg hover:bg-blue-600"
                  >
                    Save
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="bg-gray-500 text-white py-1 px-2 rounded-lg hover:bg-gray-600"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="mt-4 bg-blue-500 text-white py-1 px-2 rounded-lg hover:bg-blue-600"
              >
                Edit Profile
              </button>
            )}

            <h4 className="text-md font-semibold mt-4">Your Posts</h4>
            <div className="mt-2">
              {loading ? (
                <p className="text-gray-500">Loading posts...</p>
              ) : posts.filter((post) => post.user_id === userProfile._id).length === 0 ? (
                <p className="text-gray-500">No posts yet.</p>
              ) : (
                posts
                  .filter((post) => post.user_id === userProfile._id)
                  .map((post) => (
                    <div
                      key={post.id}
                      className="bg-gray-100 rounded-lg shadow-sm p-3 mt-2 cursor-pointer"
                      onClick={() => handlePostClick(post)}
                    >
                      <p className="text-gray-800 font-medium">{post.identity}</p>
                      <p className="text-gray-800 mt-2">{post.content}</p>
                      {post.image_urls && post.image_urls.length > 0 && (
                        <div className="mt-2">{renderImageGrid(post.image_urls)}</div>
                      )}
                    </div>
                  ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Full-Screen Image Viewer */}
      {selectedPost && (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50">
          <div className="relative w-full h-full flex items-center justify-center">
            <img
              src={selectedPost.image_urls[currentImageIndex]}
              alt="Full Screen Media"
              className="object-contain max-w-full max-h-full"
            />
            {selectedPost.image_urls.length > 1 && (
              <>
                <button
                  onClick={handlePrevImage}
                  className={`absolute left-4 top-1/2 transform -translate-y-1/2 bg-gray-800 text-white p-3 rounded-full ${
                    currentImageIndex === 0 ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                  disabled={currentImageIndex === 0}
                >
                  ←
                </button>
                <button
                  onClick={handleNextImage}
                  className={`absolute right-4 top-1/2 transform -translate-y-1/2 bg-gray-800 text-white p-3 rounded-full ${
                    currentImageIndex === selectedPost.image_urls.length - 1
                      ? "opacity-50 cursor-not-allowed"
                      : ""
                  }`}
                  disabled={currentImageIndex === selectedPost.image_urls.length - 1}
                >
                  →
                </button>
              </>
            )}
            <button
              onClick={handleClose}
              className="absolute top-4 right-4 bg-red-500 text-white p-2 rounded-full text-lg"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CommunityPage;